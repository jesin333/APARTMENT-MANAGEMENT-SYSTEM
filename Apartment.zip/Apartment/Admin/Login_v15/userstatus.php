            <?php
			include "connect.php";
			if(isset($_GET['aid'])&&isset($_GET['astatus']))
			{
				$s=$_GET['aid'];
				$a=$_GET['astatus'];
				if($a=='unblocked')
					$res=mysql_query("UPDATE `userregister` SET `status`='blocked' WHERE userid='$s'");
				else
					$res=mysql_query("UPDATE `userregister` SET `status`='unblocked' WHERE userid='$s'");
				if($res==True)
				{
					header("Refresh:0;url=userdetails.php");
				}
				else
				{
					echo "Details are not uploaded";
				}
				
			}
			?>
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
	         	