            <?php
			include "connect.php";
			
			$target_dir="C:/xampp/htdocs/Apartment/User/images/";
			$target_file = $target_dir . basename($_FILES["image"]["name"]);
			$target_file1 = "images/" . basename($_FILES["image"]["name"]);
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			// Check if image file is a actual image or fake image
			
			if(isset($_POST["btnupload"]))
			{
				$check = getimagesize($_FILES["image"]["tmp_name"]);
				$uid="0";							
				$ad1=$_POST["adrline1"];
				$ad2=$_POST["adrline2"];
				$ad3=$_POST["adrline3"];
				if(isset($_POST['r1']))
				$s=$_POST["r1"];
				$bd=$_POST["bedroom"];
				$bt=$_POST["bathroom"];
				if(isset($_POST['r2']))
				$f=$_POST["r2"];
				$ba=$_POST["builtarea"];
				$ca=$_POST["carpetarea"];
				$fl=$_POST["floors"];
				$d=$_POST["availabledate"];
				$a=$_POST["age"];
				if(isset($_POST['r3']))
				$t=$_POST["r3"];
				$c=$_POST["cost"];
				$mc=$_POST["maincost"];
				$ft=$_POST["features"];
				$ti="t1";
				$as="unblocked";
				$cs="notbooked";
				
				if(move_uploaded_file ($_FILES["image"]["tmp_name"],$target_file))
				{
				
				$res=mysql_query("insert into sales values('','$uid','$ad1','$ad2','$ad3','$s','$bd','$bt','$f','$ba','$ca','$fl','$d','$a','$t','$c','$mc','$ft','$target_file1','$as','$cs')");
				
				if($res==True)
				{
					echo "Updation is successfully completed and You will be redirected within 3 seconds";
					header("Refresh:3;url=adminhome.php");
				}
				else
				{
					echo "Details are not uploaded";
				}
				}
			}
			?>
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
	         	