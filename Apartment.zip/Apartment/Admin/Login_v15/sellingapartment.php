<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Luxury Homes a Real Estates Category Bootstrap Responsive Web Template | Codes :: w3layouts</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Luxury Homes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- css files -->
	<link href="//fonts.googleapis.com/css?family=Exo+2:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=cyrillic,latin-ext"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
	<!-- //css files -->
</head>

<body>
	<!-- banner -->
	<div class="banner-main">
		<div class="banner-2">
			<!--header-->
			<div class="header">
				<div class="container">
					<nav class="navbar navbar-default">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
							<h1><a href="sellingapartment.php"><span>L</span>uxury <span>H</span>omes</a></h1>
						</div>
						<!--navbar-header-->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li><a href="adminhome.php">Home</a></li>
								<li><a href="userdetails.php">User Details</a></li>
								<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="active">Apartment Details<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="sellingapartment.php">Selling Apartment Details</a></li>
										<li><a href="buyingapartment.php">Buying Apartment Details</a></li>
									</ul>
								</li>
								<li><a href="registration.php">Apartment Register</a></li>
                                <li><a href="logout.php">Logout</a></li>
							</ul>
						</div>
					</nav>
					<!-- cd-header-buttons -->
				</div>
			</div>
			<!--//header-->
		</div>
	</div>
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<ul class="w3_short">
				<li><a href="adminhome.php">Home</a><i>>></i></li>
				<li>Selling Apartment Details</li>
			</ul>
		</div>
	</div>
    <form>
<?php
include "connect.php";
echo "<table border='1' align='center'>
<tr><th class='text-center'>Apartment id</th>
<th class='text-center'>User id</th>
<th class='text-center'>Address</th>
<th class='text-center'>Construction Status</th>
<th class='text-center'>No. of Bedrooms</th>
<th class='text-center'>No.of Bathrooms</th>
<th class='text-center'>Furnish type</th>
<th class='text-center'>Built up of area</th>
<th class='text-center'>Carpet area</th>
<th class='text-center'>No. of Floors</th>
<th class='text-center'>Available date</th>
<th class='text-center'>Age of property</th>
<th class='text-center'>Tenant type</th>
<th class='text-center'>Cost</th>
<th class='text-center'>Maintenance cost</th>
<th class='text-center'>Features</th>
<th class='text-center'>Picture</th>
<th class='text-center'>Admin status</th>
<th class='text-center'>Customer status</th>";
$res=mysql_query("select * from sales");
while($row=mysql_fetch_array($res))
{	
	$ai=$row[0];
	$u=$row[1];		
	$ad1=$row[2];
	$ad2=$row[3];
	$ad3=$row[4];
	$s=$row[5];
	$bd=$row[6];
	$bt=$row[7];
	$f=$row[8];
	$ba=$row[9];
	$ca=$row[10];
	$fl=$row[11];
	$d=$row[12];
	$a=$row[13];
	$t=$row[14];
	$c=$row[15];
	$mc=$row[16];
	$ft=$row[17];
	$p=$row[18];
	$as=$row[19];
	$cs=$row[20];
	echo "<tr><td align='center'>$ai</td>
	<td align='center'>$u</td>
	<td align='center'>$ad1, $ad2, $ad3</td>
	<td align='center'>$s</td>
	<td align='center'>$bd</td>
	<td align='center'>$bt</td>
	<td align='center'>$f</td>
	<td align='center'>$ba</td>
	<td align='center'>$ca</td>
	<td align='center'>$fl</td>
	<td align='center'>$d</td>
	<td align='center'>$a</td>
	<td align='center'>$t</td>
	<td align='center'>$c</td>
	<td align='center'>$mc</td>
	<td align='center'>$ft</td>
    <td align='center'>";?>
	<img src='../../User/<?php echo $p;?>' height='150' width='150'>
	<?php echo"</td>
	<td align='center'><a href='editstatus.php?aid=$ai&astatus=$as'>$as</a></td>
	<td align='center'>$cs</td>";
}
echo "</table>";
mysql_close();				
?>
</form>
	<!-- //banner -->
	<!-- Codes -->
	<div class="typo"></div>
	<!-- //Codes -->

	<!-- newsletter --><!-- //newsletter -->
	<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3_footer_grids">
			  <div class="clearfix"></div>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>© 2019 Luxury Homes. All Rights Reserved | Design by Ambily and Rosemariya</p>
		</div>
	</div>
	<!-- //footer -->

	<!-- js-scripts -->
	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling -->
	<!--search jQuery-->
	<script src="js/main.js"></script>
	<!--//search jQuery-->
	<!-- js-scripts -->

</body>

</html>