<?php 
session_start();
if(isset($_SESSION['email'])&&isset($_SESSION['user']))
{ 
$u=$_SESSION['user'];
}
else
{
	header('location:index.php');
}
?><!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Luxury Homes a Real Estates Category Bootstrap Responsive Web Template | Icons :: w3layouts</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Luxury Homes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- css files -->
	<link href="//fonts.googleapis.com/css?family=Exo+2:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=cyrillic,latin-ext"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
	<!-- //css files -->
</head>

<body>
	<!-- banner -->
	<div class="banner-main">
		<div class="banner-2">
			<!--header-->
			<?php include "menu.php";?>
            <div class="header">
				<div class="container">
					<nav class="navbar navbar-default">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
							<h1><a href="bookingview.php"><span>L</span>uxury <span>H</span>omes</a></h1>
                           <h4 align="right"><a href="bookingview.php" style="color:#FCC"><span>W</span>elcome, <?php echo $name;?></a></h4>
						</div>
						<!--navbar-header-->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li><a href="home.php">Home</a></li>
								<li><a href="about.php">About</a></li>
								<li><a href="gallery.php">Gallery</a></li>
								<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Apartment details <span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="buyingapartment.php">Buying apartment details</a></li>
										<li><a href="sellingapartment.php">Selling apartment details</a></li>
									</ul>
								</li>
                                <li><a href="bookingview.php" class="active">Booking View</a></li>
								<li><a href="contact.php">Search</a></li>
                                <li><a href="logout.php">Logout</a></li>
							</ul>
						</div>
					</nav>
				</div>
			<!--//header-->
		</div>
	</div>
<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<ul class="w3_short">
				<li><a href="home.php">Home</a><i>>></i></li>
				<li>Booking View</li>
			</ul>
		</div>
	</div>
  
            <?php
			include'connect.php';
			
			$res=mysql_query("select * from booking where userid='$u'");
			while($result=mysql_fetch_array($res))
			{
			echo "<table style='border-style:double' align='center'><tr>";	
			$res1=mysql_query("select * from sales where apartmentid='$result[1]' and customerstatus='booked'");
			while($res2=mysql_fetch_array($res1))
			{
			?>
             <td colspan="2">
			<img src="<?php echo $res2[18];?>" alt="img01" data-highres="<?php echo $res2[18];?>" width="300" height="300" />
            </td></tr>
           	<tr><td align="center"><h4 style="color:#003">Address</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[2]."<br><t><t>". $res2[3]."<br><t><t>". $res2[4];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Construction Status</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[5];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">No. of Bedrooms</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[6];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">No. of Bathrooms</h4></td><t>:<td align="center"><b> <h4 style="color:#336"><?php echo $res2[7];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Furnish Type</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[8];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Built up of area</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[9]." sqft.";?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Carpet area</h4></td><td align="center"><b><h4 style="color:#336"><?php echo $res2[10]." sqft.";?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">No. of floors</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[11];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Available date</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[12];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Age of the property</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[13]." years";?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Tenanat type</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[14];?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Cost</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[15]." Rs.";?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Maintenance cost</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[16]." Rs.";?></b></h4></td></tr>
            <tr><td align="center"><h4 style="color:#003">Features</h4></td><t>:<td align="center"><b><h4 style="color:#336"><?php echo $res2[17];?></b></h4></td></tr>
            <tr><td>
            <br>
            </td></tr>
            <tr><td>
            <?php
			if($res2[1]==0)
				{
					echo "<tr><td></td><td><h3 style='color:#003'>Contact No.:0480-2770611</h3>";
					echo "<h2 style='color:#F06'><a href='bookcancel.php?aid=$res2[0];&uid=$res2[1]'><i>Cancel Booking</i></a></h2></td></tr>";
				}/*'bookcancel.php?*/
				else
				{
				$res3=mysql_query("SELECT * FROM `userregister` WHERE `userid`='$res2[1]'");
				while($res4=mysql_fetch_array($res3))
				{
			?>
            </td>
            </tr>
            <tr><td><h3 style='color:#003'>Contact no.:</h3></td><td><b><h3 style='color:#003'><?php echo $res4[4].", ".$res4[5];?></h3></b></td></tr>
            <tr><td align="center" colspan="2"><a href="bookcancel.php?aid=<?php echo $res2[0];?>&uid=<?php echo $res2[1];?>"><h2 style="color:#069"><i>Cancel Booking</i></h2></a>
             </td></tr>
          
            <?php
			}
				}
			}
			}
			echo "</table>";
			?>
	<!-- //banner -->
	<!-- icons --><!-- //icons -->

	<!-- newsletter -->
	<!-- //newsletter -->
	<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3_footer_grids">
			  <div class="clearfix"> </div>
		  </div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>© 2019 Luxury Homes. All Rights Reserved | Design by Ambily and Rosemariya</p>
		</div>
	</div>
	<!-- //footer -->

	<!-- js-scripts -->
	<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->
	<!-- smooth scrolling -->
<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling -->
	<!--search jQuery-->
<script src="js/main.js"></script>
	<!--//search jQuery-->
	<!-- js-scripts -->

</body>

</html>