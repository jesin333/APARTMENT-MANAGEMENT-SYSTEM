 <?php
 session_start();
			include "connect.php";
			
			$d=date("Y/m/d");
			if(isset($_GET['aid'])&&isset($_GET['uid']))
			{
				$aid=$_GET['aid'];
				$uid=$_GET['uid'];
				$res=mysql_query("delete from booking where apartmentid='$aid'");
				$res1=mysql_query("UPDATE `sales` SET `customerstatus`='notbooked' WHERE apartmentid='$aid'");
				if($res&&$res1)
				{
					echo "Booking is cancelled and You will be redirected within 3 seconds";
					header("Refresh:3;url=home.php");
				}
				else
				{
					echo "Details are not uploaded";
				}
				
			}
			?>