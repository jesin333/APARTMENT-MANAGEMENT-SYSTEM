<?php
session_start();
ob_start();
if(isset($_SESSION['email']))
{	
	unset($_SESSION['email']);
}
header("location:index.php");
?>
	