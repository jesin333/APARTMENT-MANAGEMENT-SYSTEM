<?php 
session_start();
if(isset($_SESSION['email'])&&isset($_SESSION['user']))
{ 

}
else
{
	header('location:index.php');
}
?><!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Luxury Homes a Real Estates Category Bootstrap Responsive Web Template | Codes :: w3layouts</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Luxury Homes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- css files -->
	<link href="//fonts.googleapis.com/css?family=Exo+2:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=cyrillic,latin-ext"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
	<!-- //css files -->
</head>

<body>
	<!-- banner -->
	<div class="banner-main">
		<div class="banner-2">
			<!--header-->
			<?php include "menu.php";?>
            <div class="header">
				<div class="container">
					<nav class="navbar navbar-default">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
							<h1><a href="sellingapartment.php"><span>L</span>uxury <span>H</span>omes</a></h1>
                           <h4 align="right"><a href="sellingapartment.php" style="color:#FCC"><span>W</span>elcome, <?php echo $name;?></a></h4>
						</div>
						<!--navbar-header-->
                      
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li><a href="home.php">Home</a></li>
								<li><a href="about.php">About</a></li>
								<li><a href="gallery.php">Gallery</a></li>
								<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="active">Apartment details <span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="buyingapartment.php">Buying apartment details</a></li>
										<li><a href="sellingapartment.php">Selling apartment details</a></li>
									</ul>
								</li>
                                <li><a href="bookingview.php">Booking View</a></li>
								<li><a href="contact.php">Search</a></li>
                                <li><a href="logout.php">Logout</a></li>
							</ul>
						</div>
					</nav>
				</div>
				<div class="cd-main-header">
					<ul class="cd-header-buttons">
						
					</ul>
					<!-- cd-header-buttons -->
				</div>
			</div>
			<!--//header-->
		</div>
	</div>
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<ul class="w3_short">
				<li><a href="home.php">Home</a><i>>></i></li>
				<li>Selling apartment details</li>
			</ul>
		</div>
	</div>
    <form method="post" action="verifysales.php" enctype="multipart/form-data">
                    <table align="center">
                    <tr><td><h3 style="color:#069">Address Line 1</h3></td>
					<td><h4 style="color:#000"><input type="text" name="adrline1" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Address Line 2</h3></td>
					<td><h4 style="color:#000"><input type="text" name="adrline2" required></td></tr><tr><td>&nbsp;</td></tr>
                     <tr><td><h3 style="color:#069">Address Line 3</h3></td>
					<td><h4 style="color:#000"><input type="text" name="adrline3" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Construction status :</h3></td>
                    <td><input type="radio" name="r1" value="Ready to move"><h5 style="color:#069">Ready to Move</h5></td>
                    <td><input type="radio" name="r1" value="Under construction"><h5 style="color:#069">Under construction</h5></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">NO. of Bedrooms</h3></td>
					<td><h4 style="color:#000"><input type="text" name="bedroom" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">No. of Bathrooms</h3></td>
					<td><h4 style="color:#000"><input type="text" name="bathroom" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Furnish Type :</h3></td>
                    <td><input type="radio" name="r2" value="Fully furnished"><h5 style="color:#069">Fully furnished</h5></td>
                    <td><input type="radio" name="r2" value="Semi furnished"><h5 style="color:#069">Semi furnished</h5></td>
                    <td><input type="radio" name="r2" value="Unfurnished"><h5 style="color:#069">Unfurnished</h5></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Built up of area (in sq.ft)</h3></td>
                    <td><h4 style="color:#069"><input type="text" name="builtarea" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Carpet area (in sq.ft)</h3></td>
                    <td><h4 style="color:#000"><input type="text" name="carpetarea" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">NO. of Floors</h3></td>
                    <td><h4 style="color:#000"><input type="text" name="floors" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Available from</h3></td>
                    <td><h4 style="color:#069"><input type="date" name="availabledate" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Age of property</h3></td>
                    <td><h4 style="color:#000"><input type="text" name="age" required></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td><h3 style="color:#069">Tenant type :</h3></td>
                    <td><input type="radio" name="r3" value="Family"><h5 style="color:#069">Family</h5></td>
                    <td><input type="radio" name="r3" value="Bachelors"><h5 style="color:#069">Bachelors</h5></td>
                     <td><input type="radio" name="r3" value="Company"><h5 style="color:#069">Company</h5></td></tr><tr><td>&nbsp;</td></tr>
                   <tr><td><h3 style="color:#069">Cost :</h3></td>
                     <td><h4 style="color:#000"><input type="text" name="cost" required></td></tr><tr><td>&nbsp;</td></tr>
                     <tr><td><h3 style="color:#069">Maintenance Cost :</h3></td>
                      <td><h4 style="color:#000"><input type="text" name="maincost" required></td></tr><tr><td>&nbsp;</td></tr>
                      <tr><td><h3 style="color:#069">Features and facilities of your apartment:</h3></td>
					<td><h4 style="color:#000"><textarea name="features" rows="5" required></textarea></td></tr><tr><td>&nbsp;</td></tr>
                    <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                     <tr><td><h3 style="color:#069"><input type="file" name="image" id="image"></h4></td>
                     <td><h4 style="color:#069"><input type="submit" value="Upload" name="btnupload"></h4>&nbsp;
                     <span class="glyphicon glyphicon-paste" aria-hidden="true"></span> <span class="glyphicon-class"></span></td></tr>
                    </table>
				</form>
	<!-- //banner -->
	<!-- Codes --><!-- //Codes -->

	<!-- newsletter --><!-- //newsletter -->
	<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3_footer_grids">
				<div class="col-md-4 w3_footer_grid-main">
					<h2><a><span>L</span>uxury <span>H</span>omes</a></h2>
					<p>You can contact with us through emails about our apartment facilities and services in more...</p>
				</div>
				<div class="col-md-4 w3_footer_grid-main-2">
					<div class="midle-w3l">
						<p>Luxury <span>Homes</span></p>
					</div>
				</div>
				<div class="col-md-4 w3_footer_grid-main">
					<div class="w3_footer_grid">
						<div class="col-xs-2 w3l_footer_grid">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
						<div class="col-xs-10 address-right">
							<h4>Address</h4>
							<p>near LULU hyper market,Edappilly,Kochi</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="w3_footer_grid">
						<div class="col-xs-2 w3l_footer_grid">
							<i class="fa fa-phone" aria-hidden="true"></i>
						</div>
						<div class="col-xs-10 address-right">
							<h4>Call Us</h4>
							<p>(0480)2770611</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="w3_footer_grid">
						<div class="col-xs-2 w3l_footer_grid">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</div>
						<div class="col-xs-10 address-right">
							<h4>Mail Us</h4>
						  <p><a>rosechukkiriyan@gmail.com</a></p>
                           <p><a>ambilywilsonk@gmail.com</a></p>
					  </div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>© 2019 Luxury Homes. All Rights Reserved | Design by Ambily and Rosemariya</p>
		</div>
	</div>
	<!-- //footer -->

	<!-- js-scripts -->
	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling -->
	<!--search jQuery-->
	<script src="js/main.js"></script>
	<!--//search jQuery-->
	<!-- js-scripts -->

</body>
</html>
<script>
$(document).ready(function()
{
	$('#insert').click(function()
	{
		var image_name=$('#image').val();
		if(image_name=='')
		{
			alert("Please select image");
			return false;
		}
		else
		{
			var extension=$('#image').val().split('.').pop().toLowerCase();
			if(jQuery.inArray(extention['gif','png','jpeg'])==-1)
			{
				alert("Invalid image file");
				$('#image').val('');
				return false;
			}
		}
	});
});
</script>
				
	