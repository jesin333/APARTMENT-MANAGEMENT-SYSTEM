            <?php
			include "connect.php";
			session_start();
if(isset($_SESSION['email'])&&isset($_SESSION['user']))
{ 

}
else
{
	header('location:index.php');
}
			if(isset($_POST["btnsave"]))
			{	
				$u=$_SESSION["user"];
				$l=$_POST["location"];
				$bf=$_POST["budgetfrom"];
				$bt=$_POST["budgetto"];
				$d=$_POST["description"];
				$res=mysql_query("insert into buying values('','$u','$l','$bf','$bt','$d')");
				if($res==True)
				{
					echo "Updation is successfully completed and You will be redirected within 3 seconds";
					header("Refresh:3;url=home.php");
				}
				else
				{
					echo "Details are not uploaded";
				}
			}
			?>
			