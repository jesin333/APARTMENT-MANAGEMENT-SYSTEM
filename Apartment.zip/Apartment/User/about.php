<?php 
session_start();
if(isset($_SESSION['email'])&&isset($_SESSION['user']))
{ 

}
else
{
	header('location:index.php');
}
?><!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Luxury Homes a Real Estates Category Bootstrap Responsive Web Template | About :: w3layouts</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Luxury Homes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css' />
	<!-- css files -->
	<link href="//fonts.googleapis.com/css?family=Exo+2:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=cyrillic,latin-ext"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
	<!-- //css files -->
</head>

<body>
	<!-- banner -->
	<div class="banner-main">
		<div class="banner-2">
			<!--header-->
			<?php include "menu.php";?>
			<div class="header">
				<div class="container">
					<nav class="navbar navbar-default">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
							<h1><a href="about.php"><span>L</span>uxury <span>H</span>omes</a></h1>
                           <h4 align="right"><a href="about.php" style="color:#FCC"><span>W</span>elcome, <?php echo $name;?></a></h4>
						</div>
						<!--navbar-header-->
                        <form name="form1" id="form1" action="">
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li><a href="home.php" >Home</a></li>
								<li><a href="about.php" class="active">About</a></li>
								<li><a href="gallery.php">Gallery</a></li>
								<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Apartment details <span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="buyingapartment.php">Buying apartment details</a></li>
										<li><a href="sellingapartment.php">Selling apartment details</a></li>
									</ul>
								</li>
                                <li><a href="bookingview.php">Booking View</a></li>
								<li><a href="contact.php">Search</a></li>
                                <li><a href="logout.php">Logout</a></li>
							</ul>
						</div>
					</nav>
				</div>
				<div class="cd-main-header">
					<ul class="cd-header-buttons">
						
					</ul>
					<!-- cd-header-buttons -->
				</div>
			</div> 
			<!--//header-->
		</div>
	</div>
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<ul class="w3_short">
				<li><a href="home.php">Home</a><i>>></i></li>
				<li>About</li>
			</ul>
		</div>
	</div>
	<!-- //banner -->
	<!-- about -->
	<div class="about">
		<div class="container">
			<h3 class="w3l-titles"  style="color:#336">What We Do</h3>
			<div class="col-md-6 about-w3right">
				<img src="images/ab.jpg" class="img-responsive" alt="" />
			</div>
			<div class="col-md-6 about-w3left">
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h5 class="panel-title asd">
								<a class="pa_italic collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false"
								    aria-controls="collapseOne">
								<span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>Apartments Tailored to Your Highest Standards
							</a>
							</h5>
						</div>
						<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false"
						    style="height: 0px;">
							<div class="panel-body panel_text">
								we should provide the facilities for your beauty of mind,body and your life through ayurveda or other treatment facilities and entertainment choices like swimming pools,play grounds,hot and spicy restaurants at it's extreme.
						  </div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h5 class="panel-title asd">
								<a class="pa_italic collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false"
								    aria-controls="collapseTwo">
								<span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>Head-turning Style in Extraordinary Location.</a>
							</h5>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false"
						    style="height: 0px;">
							<div class="panel-body panel_text">
								site of natural beauty like beaches,mountains and illusory nights for your dream projects.
						  </div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h5 class="panel-title asd">
								<a class="pa_italic collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false"
								    aria-controls="collapseThree">
								<span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>Warm Up with Our Hot Specials.
							</a>
							</h5>
						</div>
						<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" aria-expanded="false"
						    style="height: 0px;">
							<div class="panel-body panel_text">
								we ensure the top most apartments in the different cities in different districts and states through providing our special offers and cultural experiences.
						  </div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFour">
							<h5 class="panel-title asd">
								<a class="pa_italic" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true"
								    aria-controls="collapseFour">
								<span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>Falling Leaves … Falling Prices! They’re Both Happening at luxury homes.</a>
							</h5>
						</div>
						<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour" aria-expanded="true">
							<div class="panel-body panel_text">
								luxury homes provides you high quality facilities and services without making big losses in your savings.
						  </div>
						</div>
					</div>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //about -->
	<!-- advantages -->
	<div class="two-grids">
		<div class="container">
			<h3 class="w3l-titles">Advantages</h3>
			<p class="w3layouts_dummy_para">Custom Designed with the Latest Technologies</p>
			<div class="col-md-6 w3_two_grid_right">
				<div class="w3_two_grid_right1">
					<div class="col-xs-3 w3_two_grid_right_grid">
						<div class="w3_two_grid_right_grid1">
							<i class="fa fa-hourglass-o" aria-hidden="true"></i>
						</div>
					</div>
					<div class="col-xs-9 w3_two_grid_right_gridr">
						<h4>Home Managers</h4>
						<p>&nbsp;</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="w3_two_grid_right1">
					<div class="col-xs-3 w3_two_grid_right_grid">
						<div class="w3_two_grid_right_grid1">
							<i class="fa fa-clone" aria-hidden="true"></i>
						</div>
					</div>
					<div class="col-xs-9 w3_two_grid_right_gridr">
						<h4>Special Deals</h4>
						<p>&nbsp;</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="w3_two_grid_right1">
					<div class="col-xs-3 w3_two_grid_right_grid">
						<div class="w3_two_grid_right_grid1">
							<i class="fa fa-external-link" aria-hidden="true"></i>
						</div>
					</div>
					<div class="col-xs-9 w3_two_grid_right_gridr">
						<h4>Residential</h4>
						<p>.</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<div class="col-md-6 w3_two_grid_right">
				<div class="w3_two_grid_right1">
					<div class="col-xs-3 w3_two_grid_right_grid">
						<div class="w3_two_grid_right_grid1">
							<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
						</div>
					</div>
					<div class="col-xs-9 w3_two_grid_right_gridr">
						<h4>Ideal Layout</h4>
						<p>&nbsp;</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="w3_two_grid_right1">
					<div class="col-xs-3 w3_two_grid_right_grid">
						<div class="w3_two_grid_right_grid1">
							<i class="fa fa-check-square-o" aria-hidden="true"></i>
						</div>
					</div>
					<div class="col-xs-9 w3_two_grid_right_gridr">
						<h4>Custom Designed</h4>
						<p>.</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="w3_two_grid_right1">
					<div class="col-xs-3 w3_two_grid_right_grid">
						<div class="w3_two_grid_right_grid1">
							<i class="fa fa-square-o" aria-hidden="true"></i>
						</div>
					</div>
					<div class="col-xs-9 w3_two_grid_right_gridr">
						<h4>Best House</h4>
						<p>.</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //advantages -->
	<!-- team -->
	<div class="team" id="team">
		<div class="container">
			<div class="w3-agileits-team-title">
				<h3 class="w3l-titles" style="color:#336">Our Agents</h3>
				<div id="horizontalTab">
					<ul class="col-md-2 resp-tabs-list">
						<li>
							<img src="images/a2.jpg" alt=" " class="img-responsive" />
						</li>
						<li>
							<img src="images/a1.jpg" alt=" " class="img-responsive" />
						</li>
						<li></li>
						<li></li>
					</ul>
					<div class="col-md-10 resp-tabs-container">
						<div class="tab1">
							<div class="col-md-6 team-Info-agileits">
								<h4>Ambily Wilson</h4>
								<span>Agent 1</span>
								<p>Managing director of luxury homes in Kochin branch works with various luxury apartments for the better dealers and their transactions</p>
								<div class="social-bnr-agileits footer-icons-agileinfo">
									<ul class="social-icons3">
										<li>Contact no.:</li>
										<li>(0480)2770611,</li>
										<li>Email id:</li>
										<li>ambilywilsonk@gmail.com</li>

									</ul>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="tab2">
							<div class="col-md-6 team-Info-agileits">
								<h4>Rosemariya Joy</h4>
								<span>Agent 2</span>
								<p>Managing director of luxury homes in Banglore branch deals with attractive apartments for the spectaculous growth of luxury homes.</p>
								<div class="social-bnr-agileits footer-icons-agileinfo">
									<ul class="social-icons3">
										<li>Contact no.:</li>
										<li>9605777908,</li>
										<li>Email id:</li>
										<li>rosechukkiriyan@gmail.com</li>

									</ul>
								</div>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="tab3">
						  <div class="clearfix"> </div>
						</div>
						<div class="tab4">
						  <div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div>
	<!-- //team -->
	<!-- stats -->
	<div class="stats">
		<div class="wthree_stat">
			<div class="container">
				<div class="wthree_stat_right">
					<ul>
						<li>
							<div class="wthree_stat_right1">
								<i class="fa fa-users" aria-hidden="true"></i>
								<h4>Happy clients</h4>
								<p class="counter">1200</p>
							</div>
						</li>
						<li>
							<div class="wthree_stat_right1">
								<i class="fa fa-trophy" aria-hidden="true"></i>
								<h4>Awards</h4>
								<p class="counter">800</p>
							</div>
						</li>
						<li>
							<div class="wthree_stat_right1">
								<i class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></i>
								<h4>Agencies</h4>
								<p class="counter">500</p>
							</div>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //stats -->
	<!-- newsletter --><!-- //newsletter -->
	<!-- footer -->
	<div class="footer">
		<div class="container">
			<div class="w3_footer_grids">
				<div class="col-md-4 w3_footer_grid-main">
					<h2><a><span>L</span>uxury <span>H</span>omes</a></h2>
					<p>You can contact with us through emails about our apartment facilities and services in more...</p>
				</div>
				<div class="col-md-4 w3_footer_grid-main-2">
					<div class="midle-w3l">
						<p>Luxury <span>Homes</span></p>
					</div>
				</div>
				<div class="col-md-4 w3_footer_grid-main">
					<div class="w3_footer_grid">
						<div class="col-xs-2 w3l_footer_grid">
							<i class="fa fa-home" aria-hidden="true"></i>
						</div>
						<div class="col-xs-10 address-right">
							<h4>Address</h4>
							<p>near LULU hyper market,Edappilly,Kochi</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="w3_footer_grid">
						<div class="col-xs-2 w3l_footer_grid">
							<i class="fa fa-phone" aria-hidden="true"></i>
						</div>
						<div class="col-xs-10 address-right">
							<h4>Call Us</h4>
							<p>(0480)2770611</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="w3_footer_grid">
						<div class="col-xs-2 w3l_footer_grid">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</div>
						<div class="col-xs-10 address-right">
							<h4>Mail Us</h4>
						  <p><a>rosechukkiriyan@gmail.com</a></p>
                           <p><a>ambilywilsonk@gmail.com</a></p>
					  </div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>© 2019 Luxury Homes. All Rights Reserved | Design by Ambily and Rosemariya</p>
		</div>
	</div>
	<!-- //footer -->

	<!-- js-scripts -->
	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->
	<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->
	<!--search jQuery-->
	<script src="js/main.js"></script>
	<!--//search jQuery-->
	<!-- tabs -->
	<script src="js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true, // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function (event) { // Callback function if tab is switched
					var $tab = $(this);
					var $info = $('#tabInfo');
					var $name = $('span', $info);
					$name.text($tab.text());
					$info.show();
				}
			});
			$('#verticalTab').easyResponsiveTabs({
				type: 'vertical',
				width: 'auto',
				fit: true
			});
		});
	</script>
	<!-- //tabs -->
	<!-- stats -->
	<script src="js/waypoints.min.js"></script>
	<script src="js/counterup.min.js"></script>
	<script>
		jQuery(document).ready(function ($) {
			$('.counter').counterUp({
				delay: 100,
				time: 1000
			});
		});
	</script>
	<!-- stats -->
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling -->
	<!-- js-scripts -->

</body>

</html>