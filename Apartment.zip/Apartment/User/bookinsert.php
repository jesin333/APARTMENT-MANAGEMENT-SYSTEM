 <?php
 session_start();

if(isset($_SESSION['email'])&&isset($_SESSION['user']))
{ 

}
else
{
	header('location:index.php');
}
			include "connect.php";
			
			$d=date("Y/m/d");
			if(isset($_GET['aid']))
			{
				$aid=$_GET['aid'];
				$uid=$_SESSION['user'];
				$res=mysql_query("insert into booking values('','$aid','$uid','$d')");
				$res1=mysql_query("UPDATE `sales` SET `customerstatus`='booked' WHERE apartmentid='$aid'");
				if($res&&$res1)
				{
					echo "Booking is successfully completed and You will be redirected within 3 seconds";
					header("Refresh:3;url=home.php");
				}
				else
				{
					echo "Details are not uploaded";
				}
				
			}
			?>