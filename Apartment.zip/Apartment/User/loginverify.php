 <?php
 	session_start();
	include "connect.php";
	if(isset($_POST["btnsub"]))
	{	
		$u=$_POST["username"];
		$p=$_POST["pass"];
		$res=mysql_query("select * from userregister where email='$u'and password='$p'");
		while($res3=mysql_fetch_array($res))
		{
			if($res3[9]=='blocked')
			{
				echo "Sorry You  Can't Login This Website. You Were Bloked By Admin...<br>For More Details Please Contact Our                   Agents...";
				header('refresh:3;url=login.php');
			}
			else
			{
				$res1=mysql_query("select * from userregister where email='$u'and password='$p' and status='unblocked'");
				
					if(mysql_num_rows($res1)>0)
					{
						while($ob1=mysql_fetch_array($res1))
						{
							$_SESSION['email']=$ob1[7];
							$_SESSION['user']=$ob1[0];
						}
						header("location:home.php");
					}
					else
					{
						echo "wrong username or password.Try again";
						header('refresh:3;url=login.php');	
					}
				}
			
		}
	}
	mysql_close();
?>
	