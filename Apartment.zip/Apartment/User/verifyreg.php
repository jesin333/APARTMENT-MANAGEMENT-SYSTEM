            <?php
			include "connect.php";
			if(isset($_POST["btnsub"]))
				{	
				$f=$_POST["firstname"];
				$l=$_POST["lastname"];
				if(isset($_POST['r1']))
				$g=$_POST["r1"];
				$ph=$_POST["phno"];
				$m=$_POST["mobno"];
				$a=$_POST["address"];
				$e=$_POST["email"];
				$p=$_POST["password1"];
				$cp=$_POST["password2"];
				$s="unblocked";
				if($p==$cp)
				{
					$res=mysql_query("insert into userregister values('','$f','$l','$g','$ph','$m','$a','$e','$p','$s')");
					if($res)
						echo "Registration is successfully completed and You will be redirected within 3 seconds";
						header("Refresh:3;url=index.php");
				}
				else
					echo "Password doesn't match";
				}
				mysql_close();
			?>