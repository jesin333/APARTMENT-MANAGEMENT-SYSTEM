<?php 

if(isset($_SESSION['email'])&&isset($_SESSION['user']))
{ 

}
else
{
	header('location:index.php');
}

 	$e=$_SESSION['user'];
	include 'connect.php';
	$r=mysql_query("SELECT * FROM `userregister` WHERE `userid`='$e'");
	while($obj=mysql_fetch_array($r))
	{
		$fname=$obj[1];
		$lname=$obj[2];
		$name=$fname.' '.$lname;
	}	
?>
