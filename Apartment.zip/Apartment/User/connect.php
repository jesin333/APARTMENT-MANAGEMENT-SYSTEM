<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
<?php
$con=mysql_connect("localhost","root","");
				if($con==FALSE)
				{
					echo "Cannot establish connection";
				}
				$flag=mysql_select_db("apartment");
				if($flag==FALSE)
				{
					echo "Database is not selected";
				}
?>
</body>
</html>