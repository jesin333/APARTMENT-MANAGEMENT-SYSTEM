-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2019 at 08:52 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apartment`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`username`, `password`) VALUES
('admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingid` int(4) NOT NULL,
  `apartmentid` int(4) NOT NULL,
  `userid` int(4) NOT NULL,
  `bookingdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingid`, `apartmentid`, `userid`, `bookingdate`) VALUES
(5, 35, 15, '2019-03-05'),
(6, 31, 15, '2019-03-05'),
(7, 36, 8, '2019-03-05'),
(9, 37, 18, '2019-03-18'),
(10, 30, 18, '2019-03-18');

-- --------------------------------------------------------

--
-- Table structure for table `buying`
--

CREATE TABLE `buying` (
  `buyingid` int(4) NOT NULL,
  `userid` int(4) NOT NULL,
  `location` varchar(20) NOT NULL,
  `budgetfrom` int(4) NOT NULL,
  `budgetto` int(4) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buying`
--

INSERT INTO `buying` (`buyingid`, `userid`, `location`, `budgetfrom`, `budgetto`, `description`) VALUES
(6, 15, 'Vennattukara', 40000, 4000000, 'Echo friendly,Near hospital'),
(7, 13, 'Meloor', 500000, 1000000, 'More than 3 rooms,Good infrastructure'),
(8, 18, 'thrissur', 50000, 250000, 'bedrooms 4\r\nbathroom 4');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `apartmentid` int(4) NOT NULL,
  `userid` int(4) NOT NULL,
  `adrline1` varchar(30) NOT NULL,
  `adrline2` varchar(30) NOT NULL,
  `adrline3` varchar(30) NOT NULL,
  `cstatus` varchar(20) NOT NULL,
  `bedroom` int(4) NOT NULL,
  `bathroom` int(4) NOT NULL,
  `furnish` varchar(20) NOT NULL,
  `builtarea` float NOT NULL,
  `carpetarea` float NOT NULL,
  `floors` int(4) NOT NULL,
  `availabledate` date NOT NULL,
  `age` int(4) NOT NULL,
  `tenanttype` varchar(10) NOT NULL,
  `cost` float NOT NULL,
  `maincost` float NOT NULL,
  `features` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `adminstatus` varchar(10) NOT NULL,
  `customerstatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`apartmentid`, `userid`, `adrline1`, `adrline2`, `adrline3`, `cstatus`, `bedroom`, `bathroom`, `furnish`, `builtarea`, `carpetarea`, `floors`, `availabledate`, `age`, `tenanttype`, `cost`, `maincost`, `features`, `image`, `adminstatus`, `customerstatus`) VALUES
(28, 8, 'Kallettumkara', 'Kodakara', 'Chalakudy', 'Ready to move', 3, 2, 'Semi furnished', 10000, 2000, 1, '2019-03-29', 0, 'Family', 800000, 10000, 'Good Atmosphere,\r\nGood transportation facility,Near hospital', 'images/im1.jpg', 'unblocked', 'notbooked'),
(29, 8, 'Kayamkulam', 'kollur', 'Kottayam', 'Under construction', 5, 4, 'Unfurnished', 120000, 23999, 2, '2019-04-06', 0, 'Company', 2000000, 2000, 'Good infrastructure\r\nHigh security\r\nMore area', 'images/im2.jpg', 'unblocked', 'notbooked'),
(30, 8, 'Vennoor', 'Annamanada p.o', 'Koratty', 'Ready to move', 4, 4, 'Fully furnished', 8200, 1000, 2, '2019-03-14', 4, 'Bachelors', 5000000, 20000, 'Nature friendly\r\nGood neighbours\r\n', 'images/im3.jpg', 'unblocked', 'booked'),
(31, 8, 'No. 22 street', 'Kaloor', 'Ernakulam', 'Ready to move', 2, 0, 'Fully furnished', 5000, 100, 1, '2019-03-10', 12, 'Family', 500000, 1000, 'City based area\r\nNear railway station,hopitals,sch', 'images/4.jpg', 'unblocked', 'booked'),
(32, 9, 'kankamala', 'kodakara p.o', 'Chalakudy', 'Under construction', 3, 3, 'Unfurnished', 15000, 1000, 2, '2020-02-24', 0, 'Bachelors', 300000, 10000, 'Good tranportation facility,\r\nGood nature\r\n', 'images/5.jpg', 'blocked', 'notbooked'),
(33, 9, 'karoor', 'aloor p.o', 'kodakara', 'Ready to move', 4, 4, 'Fully furnished', 4000, 1500, 3, '2019-03-20', 2, 'Company', 30000000, 100000, 'Water facility,\r\necho friendly,\r\nshools and hospital', 'images/6.jpg', 'unblocked', 'notbooked'),
(34, 9, 'ravipuram', 'kallam p.o', 'Kottayam', 'Ready to move', 4, 4, 'Fully furnished', 4500, 500, 3, '2019-03-26', 3, 'Company', 1000000, 50000, 'good infrastructure\r\n', 'images/7.jpg', 'unblocked', 'notbooked'),
(35, 16, 'Nellayi', 'Nellimkulam p.o', 'kodancherry', 'Ready to move', 7, 12, 'Semi furnished', 500000, 20000, 6, '2019-03-27', 5, 'Company', 10000000, 100000, 'availability of fresh air,\r\nWater availabilty,\r\nGood infrastructure', 'images/8.jpg', 'unblocked', 'booked'),
(36, 16, 'Malayattoor', 'Puthukkad p.o', 'Kozhikode', 'Ready to move', 2, 2, 'Fully furnished', 39000, 1200, 1, '2019-05-15', 6, 'Bachelors', 501000, 1000, 'Echo friendly,\r\nForest area\r\n', 'images/9.jpg', 'unblocked', 'booked'),
(37, 17, 'Pandipakam', 'Maattupetti', 'Munnar', 'Under construction', 1, 1, 'Unfurnished', 5000, 100, 1, '2019-03-20', 0, 'Bachelors', 500000, 1500, 'Forest area,\r\nCool air', 'images/10.jpg', 'unblocked', 'booked'),
(38, 17, 'konchipattanam', 'Malakkapara p.o', 'valparai', 'Ready to move', 3, 2, 'Fully furnished', 1500, 300, 3, '2019-04-17', 8, 'Family', 120500, 1000, 'Near Athirapilly waterfall,\r\nSurrounded by shops and restaurants', 'images/11.jpg', 'unblocked', 'notbooked'),
(39, 17, 'Chinjamattam', 'kecheri p.o', 'kozhipalam', 'Ready to move', 2, 2, 'Fully furnished', 3000, 500, 1, '2019-04-02', 30, 'Family', 300000, 1000, 'Farm facilities,\r\nnear pond', 'images/12.jpg', 'unblocked', 'notbooked'),
(40, 14, 'vellamadikunnu', 'marikunnu p.o', 'Thazhekad', 'Ready to move', 3, 2, 'Semi furnished', 50000, 200, 2, '2019-03-07', 34, 'Family', 200000, 10000, 'Ayuvedic culture area,\r\ntrucking facility', 'images/13.jpg', 'unblocked', 'notbooked'),
(41, 11, 'Puloor', 'Kaazhikalam', 'irinjalakuda', 'Under construction', 2, 3, 'Semi furnished', 30000, 300, 1, '2019-03-09', 0, 'Family', 400000, 5000, 'Near christ college,\r\nGood transportation facility', 'images/14.jpg', 'unblocked', 'notbooked'),
(42, 11, 'Lahin', 'kanyakumari p.o', 'Thiruvananthapuram', 'Ready to move', 3, 8, 'Fully furnished', 100000, 40000, 2, '2019-04-10', 1, 'Company', 10000000, 500000, 'Swimming pools\r\nplayground', 'images/16.jpg', 'unblocked', 'notbooked'),
(48, 0, 'Illinois', 'Chicago', 'America', 'Ready to move', 3, 4, 'Fully furnished', 200000, 100, 1, '2019-03-28', 4, 'Bachelors', 30000000, 10000, 'Apartment in a developed area,Good infrastructure', 'images/19.jpg', 'unblocked', 'notbooked'),
(49, 9, 'Kunnamkulam', 'K.K Road', 'Kadalkattu', 'Under construction', 4, 3, 'Unfurnished', 1000000, 10000, 2, '2020-03-25', 0, 'Company', 70000000, 100000, 'Cool area, Near kinder garden ,More office spaces', 'images/15.jpg', 'unblocked', 'notbooked');

-- --------------------------------------------------------

--
-- Table structure for table `userregister`
--

CREATE TABLE `userregister` (
  `userid` int(4) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `Phno` bigint(8) NOT NULL,
  `mob` bigint(8) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregister`
--

INSERT INTO `userregister` (`userid`, `firstname`, `lastname`, `gender`, `Phno`, `mob`, `address`, `email`, `password`, `status`) VALUES
(8, 'Ambily ', 'wilson', 'Female', 9446623545, 9665456423, 'Kunnathuparambil house\r\nvennoor\r\nannamanada p.o\r\n', 'ambilywilsonk@gmail.com', 'oj', 'unblocked'),
(9, 'Rosemariya', 'joy', 'Female', 9605777908, 9605777908, 'Chukkiriyan(H)\r\nvallappady\r\np.o perambra\r\n680689', 'chukkiriyanjoy123@gmail.com', 'rose', 'unblocked'),
(10, 'Megha ', 'Xavier', 'Female', 8589069855, 9567715158, 'Konnoth house\r\nKodassery p.o\r\nNayarangadi\r\npin:680', 'meghaxavier1999@gmail.com', 'megha', 'blocked'),
(11, 'Sunilakshmi', 'K.S', 'Female', 9496864689, 9400864713, 'Kochukulam (h)\r\np.o pullur\r\nIrinjalakuda\r\nThrissur', 'sunilakshmiks123@gmail.com', 'suni', 'unblocked'),
(12, 'Selma', 'Johnson', 'Female', 480, 9443562727, 'Puthenveettil (h)\r\nPalayamparambu p.o\r\nAmbazhakkad', 'sjputhenveettil@gmail.com', 'selma', 'unblocked'),
(13, 'Anju', 'Varghese', 'Female', 9537257251, 9633824465, 'Chully (h)\r\nVallappady p.o\r\nPerambra\r\nThrissur\r\nKe', 'anjuvarghese123@gmail.com', 'anju', 'unblocked'),
(14, 'Grace Maria', 'Jose', 'Female', 9562546625, 9643781456, 'Chathely (h)\r\nKannikara p.o\r\nThazhekkad\r\nThrissur\r', 'gmj97@gmail.com', 'grace', 'unblocked'),
(15, 'Johan', 'Chummar', 'Male', 9447302703, 9524616245, 'Chittillapilly (h)\r\nPariyaram p.o\r\nChalakudy\r\nThri', 'johanchummar@gmail.com', 'johan', 'unblocked'),
(16, 'Ojes', 'Chacko', 'Male', 9643251681, 8289883831, 'Maliakkel (h)\r\nNellayi p.o\r\nKodakara\r\nThrissur\r\nKe', 'ojtheextreme@gmail.com', 'ojes', 'unblocked'),
(17, 'Tomson', 'Chinnappan', 'Male', 9763572456, 9536724357, 'Nellissery (h)\r\nValparai\r\npin:643572\r\nTamilnadu', 'tomcatz@gmail.com', 'tom', 'unblocked'),
(18, 'anna', 'Jose', 'Female', 9754567834, 9345602356, 'chully(h)\r\nvallappady\r\np.o puthukad\r\n\r\n\r\n\r\n\r\n', 'annajose@gmail.com', 'anna', 'unblocked');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingid`);

--
-- Indexes for table `buying`
--
ALTER TABLE `buying`
  ADD PRIMARY KEY (`buyingid`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`apartmentid`);

--
-- Indexes for table `userregister`
--
ALTER TABLE `userregister`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `mob` (`mob`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `buying`
--
ALTER TABLE `buying`
  MODIFY `buyingid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `apartmentid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `userregister`
--
ALTER TABLE `userregister`
  MODIFY `userid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
